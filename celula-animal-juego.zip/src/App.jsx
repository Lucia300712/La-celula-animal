import { useState } from "react";
import { motion } from "framer-motion";

const organulos = [
  { name: "Núcleo", game: "Trivia" },
  { name: "Mitocondria", game: "Plataformas" },
  { name: "Vacuola", game: "Rompecabezas" },
  { name: "Retículo Endoplasmático", game: "Laberinto" },
  { name: "Lisosoma", game: "Limpieza" },
  { name: "Citoplasma", game: "Carrera" },
  { name: "Membrana Celular", game: "Selección" },
  { name: "Ribosoma", game: "Construcción" },
  { name: "Aparato de Golgi", game: "Organización" },
];

export default function CelulaAnimalJuego() {
  const [selectedGame, setSelectedGame] = useState(null);

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-white flex flex-col items-center p-4">
      <motion.h1 className="text-4xl font-bold mb-8" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        🧬 Juego de la Célula Animal
      </motion.h1>
      {!selectedGame ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 w-full max-w-4xl">
          {organulos.map((org) => (
            <div key={org.name} className="cursor-pointer bg-white rounded-2xl shadow-md hover:shadow-lg p-6 text-center"
                 onClick={() => setSelectedGame(org)}>
              <h2 className="text-2xl font-semibold mb-2">{org.name}</h2>
              <p className="text-base">Prueba: {org.game}</p>
            </div>
          ))}
        </div>
      ) : (
        <div className="w-full max-w-2xl">
          <button onClick={() => setSelectedGame(null)} className="mb-4 px-4 py-2 bg-blue-500 text-white rounded-xl">
            ⬅ Volver
          </button>
          <div className="bg-white rounded-2xl shadow-md p-6 text-center">
            <h2 className="text-3xl font-semibold mb-4">{selectedGame.name}</h2>
            <p className="text-lg mb-6">Modo de juego: {selectedGame.game}</p>
            <div>🎮 ¡Aquí irá el minijuego correspondiente! 🎯</div>
          </div>
        </div>
      )}
    </div>
  );
}